<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Language Portal</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f9;
      padding: 30px;
      margin: 0;
    }

    .container {
      max-width: 800px;
      margin: auto;
      background: white;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
      text-align: center;
    }

    h2 {
      color: #333;
      margin-bottom: 20px;
    }

    p {
      font-size: 18px;
      color: #555;
    }

    a {
      text-decoration: none;
      color: #007bff;
      font-size: 18px;
      margin: 10px;
    }

    a:hover {
      text-decoration: underline;
    }

    .link-container {
      margin-top: 20px;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Welcome to the Language Learning Portal</h2>
  <p>To get started, please <a href="register.php">Register</a> or <a href="login.php">Login</a> to your account.</p>
</div>

</body>
</html>
