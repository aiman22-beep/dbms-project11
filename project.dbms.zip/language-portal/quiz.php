<?php
include 'db.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user']['id'];
$lesson_id = $_GET['lesson_id'];  // The lesson ID passed from the lessons page

// Check if course_id is passed, if not redirect to lessons page or show an error
if (!isset($_GET['course_id'])) {
    echo "<p style='color: red; text-align: center;'>Course ID is missing. Please go back to the lessons page.</p>";
    exit;
}

$course_id = $_GET['course_id'];  // The course ID passed from the lessons page

// Get the quiz question associated with this lesson
$stmt = $conn->prepare("SELECT * FROM quizzes WHERE lesson_id = ?");
$stmt->bind_param("i", $lesson_id);
$stmt->execute();
$quiz_result = $stmt->get_result();

if ($quiz_result->num_rows === 0) {
    echo "<p>No quiz available for this lesson.</p>";
    exit;
}

// Handle quiz submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $answer = $_POST['answer'];
    $correct_answer = $_POST['correct_answer'];

    // First, check if the user has an existing record for this lesson
    $progress_check = $conn->prepare("SELECT status FROM progress WHERE user_id = ? AND lesson_id = ?");
    $progress_check->bind_param("ii", $user_id, $lesson_id);
    $progress_check->execute();
    $progress_result = $progress_check->get_result();

    if ($progress_result->num_rows > 0) {
        // If the record exists, we check if it's correct and update the status
        if ($answer === $correct_answer) {
            $update_stmt = $conn->prepare("UPDATE progress SET status = 'completed' WHERE user_id = ? AND lesson_id = ?");
            $update_stmt->bind_param("ii", $user_id, $lesson_id);
            $update_stmt->execute();

            echo "<p style='color: green; text-align: center;'>You passed the quiz! Lesson marked as completed.</p>";
        } else {
            echo "<p style='color: red; text-align: center;'>Incorrect answer. Please try again.</p>";
        }
    } else {
        // If no record exists, insert a new progress record with 'in_progress' status
        if ($answer === $correct_answer) {
            $insert_stmt = $conn->prepare("INSERT INTO progress (user_id, lesson_id, status) VALUES (?, ?, 'completed')");
            $insert_stmt->bind_param("ii", $user_id, $lesson_id);
            $insert_stmt->execute();

            echo "<p style='color: green; text-align: center;'>You passed the quiz! Lesson marked as completed.</p>";
        } else {
            // If answer is incorrect, mark as 'in_progress'
            $insert_stmt = $conn->prepare("INSERT INTO progress (user_id, lesson_id, status) VALUES (?, ?, 'in_progress')");
            $insert_stmt->bind_param("ii", $user_id, $lesson_id);
            $insert_stmt->execute();

            echo "<p style='color: orange; text-align: center;'>Quiz started. Please try again.</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Quiz for Lesson ID <?= $lesson_id ?></title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f9;
      padding: 30px;
      margin: 0;
    }

    .container {
      max-width: 600px;
      margin: auto;
      background: white;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
    }

    h2 {
      text-align: center;
      color: #333;
      margin-bottom: 25px;
    }

    .quiz-container {
      padding: 20px;
      background: #f9f9f9;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .quiz-container label {
      font-size: 18px;
    }

    .quiz-container input {
      width: 100%;
      padding: 10px;
      margin-top: 10px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }

    button {
      width: 100%;
      padding: 12px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
    }

    button:hover {
      background-color: #0056b3;
    }

    .back-link {
      text-align: center;
      margin-top: 20px;
    }

    .back-link a {
      color: #007bff;
      text-decoration: none;
    }

    .back-link a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Quiz for Lesson ID <?= htmlspecialchars($lesson_id) ?></h2>

  <div class="quiz-container">
    <?php while ($quiz = $quiz_result->fetch_assoc()): ?>
      <form method="POST">
        <label for="answer"><?= htmlspecialchars($quiz['question']) ?></label>
        <input type="text" name="answer" required>
        <input type="hidden" name="correct_answer" value="<?= htmlspecialchars($quiz['correct_answer']) ?>">
        <button type="submit">Submit Answer</button>
      </form>
    <?php endwhile; ?>
  </div>

  <!-- Back Link to Lessons Page with course_id -->
  <div class="back-link">
    <a href="lessons.php?course_id=<?= $course_id ?>">⬅ Back to Lessons</a>
  </div>
</div>

</body>
</html>
