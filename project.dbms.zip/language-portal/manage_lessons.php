<?php
include 'db.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
  header("Location: login.php");
  exit;
}

$course_id = $_GET['course_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manage Lessons</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f9;
      padding: 30px;
      margin: 0;
    }
    .back-link {
      margin-bottom: 20px;
    }
    .back-link a {
      text-decoration: none;
      color: #007bff;
      font-size: 16px;
    }

    .container {
      max-width: 600px;
      margin: auto;
      background: white;
      border-radius: 10px;
      padding: 25px;
      box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
    }

    h2 {
      text-align: center;
      color: #333;
      margin-bottom: 25px;
    }

    input[type="text"], textarea {
      width: 100%;
      padding: 12px;
      margin-bottom: 16px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }

    textarea {
      resize: vertical;
      height: 150px;
    }

    button {
      width: 100%;
      padding: 12px;
      background-color: #28a745;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
    }

    button:hover {
      background-color: #218838;
    }

    .lesson-list {
      margin-top: 30px;
    }

    .lesson-list p {
      padding: 8px;
      background: #f8f9fc;
      border-radius: 6px;
      margin-bottom: 8px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .lesson-list strong {
      font-size: 16px;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Add Lesson to Course ID <?= htmlspecialchars($course_id) ?></h2>

  <!-- Lesson Form -->
  <form method="POST" onsubmit="return validateForm()">
    <input name="title" id="title" placeholder="Lesson Title" required>
    <textarea name="content" id="content" placeholder="Lesson Content" required></textarea>
    <input name="video_url" id="video_url" placeholder="Video URL (optional)">
    <button type="submit" name="add_lesson">Add Lesson</button>
  </form>

  <!-- Success Message -->
  <?php
  if (isset($_POST['add_lesson'])) {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $video = $_POST['video_url'];

    $stmt = $conn->prepare("INSERT INTO lessons (course_id, title, content, video_url) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $course_id, $title, $content, $video);
    $stmt->execute();
    echo "<p style='color: green; text-align: center;'>Lesson added successfully!</p>";
  }
  ?>

  <hr>
  <h3>Existing Lessons</h3>

  <div class="lesson-list">
    <?php
    $result = $conn->query("SELECT * FROM lessons WHERE course_id = $course_id");
    while ($row = $result->fetch_assoc()) {
      echo "<p><strong>" . htmlspecialchars($row['title']) . "</strong></p>";
    }
    ?>
  </div>
     <!-- back button -->
  <div class="back-link">
    <a href="admin_dashboard.php">⬅ Back to Admin Dashboard</a>
  </div>
</div>

<!-- JavaScript for form validation -->
<script>
  function validateForm() {
    const title = document.getElementById('title').value.trim();
    const content = document.getElementById('content').value.trim();

    if (!title || !content) {
      alert("Title and Content are required.");
      return false;
    }
    return true;
  }
</script>

 
 


</body>
</html>
