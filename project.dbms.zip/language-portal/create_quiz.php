<?php
include 'db.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if (isset($_POST['create_quiz'])) {
    $lesson_id = $_POST['lesson_id'];
    $question = $_POST['question'];
    $correct_answer = $_POST['correct_answer'];

    // Insert the quiz into the database
    $stmt = $conn->prepare("INSERT INTO quizzes (lesson_id, question, correct_answer) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $lesson_id, $question, $correct_answer);
    $stmt->execute();

    echo "<p style='color: green; text-align: center;'>Quiz created successfully!</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Quiz</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            padding: 30px;
            margin: 0;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 25px;
        }

        label {
            font-size: 16px;
            margin-bottom: 5px;
        }

        input[type="text"], textarea {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            color: #007bff;
            text-decoration: none;
        }

        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Create Quiz for Lesson</h2>

    <form method="POST" action="create_quiz.php">
        <label for="lesson_id">Select Lesson</label>
        <select name="lesson_id" required>
            <?php
            // Get all lessons from the database
            $lesson_stmt = $conn->prepare("SELECT * FROM lessons");
            $lesson_stmt->execute();
            $lessons = $lesson_stmt->get_result();
            while ($lesson = $lessons->fetch_assoc()) {
                echo "<option value='" . $lesson['id'] . "'>" . htmlspecialchars($lesson['title']) . "</option>";
            }
            ?>
        </select>

        <label for="question">Quiz Question</label>
        <textarea name="question" rows="4" placeholder="Enter the quiz question" required></textarea>

        <label for="correct_answer">Correct Answer</label>
        <input type="text" name="correct_answer" placeholder="Enter the correct answer" required>

        <button type="submit" name="create_quiz">Create Quiz</button>
    </form>

    <div class="back-link">
        <a href="dashboard.php">⬅ Back to Dashboard</a>
    </div>
</div>

</body>
</html>
