<?php
include 'db.php';
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user']['id'];

$stmt = $conn->prepare("
    SELECT l.title, p.status
    FROM progress p
    JOIN lessons l ON l.id = p.lesson_id
    WHERE p.user_id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Progress</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f9;
      padding: 30px;
      margin: 0;
    }

    .container {
      max-width: 600px;
      margin: auto;
      background: white;
      border-radius: 10px;
      padding: 25px;
      box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
    }

    h2 {
      text-align: center;
      color: #333;
      margin-bottom: 25px;
    }

    ul {
      list-style-type: none;
      padding-left: 0;
    }

    li {
      padding: 12px 16px;
      margin-bottom: 10px;
      border-radius: 6px;
      background: #f8f9fc;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .status {
      padding: 5px 10px;
      border-radius: 20px;
      font-size: 13px;
      font-weight: bold;
      text-transform: capitalize;
    }

    .completed {
      background: #d4edda;
      color: #155724;
    }

    .not_started {
      background: #f8d7da;
      color: #721c24;
    }

    .in_progress {
      background: #fff3cd;
      color: #856404;
    }

    .back-link {
      text-align: center;
      margin-top: 20px;
    }

    .back-link a {
      text-decoration: none;
      color: #007bff;
    }

    .back-link a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>📘 Your Lesson Progress</h2>

  <?php if ($result->num_rows > 0): ?>
    <ul>
    <?php while ($row = $result->fetch_assoc()): ?>
      <li>
        <?= htmlspecialchars($row['title']) ?>
        <span class="status <?= $row['status'] === 'completed' ? 'completed' : ($row['status'] === 'in_progress' ? 'in_progress' : 'not_started') ?>">
          <?= ucfirst($row['status']) ?>
        </span>
      </li>
    <?php endwhile; ?>
    </ul>
  <?php else: ?>
    <p>You haven’t completed any lessons yet.</p>
  <?php endif; ?>

  <div class="back-link">
    <a href="dashboard.php">⬅ Back to Dashboard</a>
  </div>
</div>

</body>
</html>
