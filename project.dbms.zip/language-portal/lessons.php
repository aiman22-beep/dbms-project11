<?php
include 'db.php';
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit;
}

$user_id = $_SESSION['user']['id'];
$course_id = $_GET['course_id'];

// Get lessons
$stmt = $conn->prepare("SELECT * FROM lessons WHERE course_id = ?");
$stmt->bind_param("i", $course_id);
$stmt->execute();
$lessons = $stmt->get_result();

// Handle mark as complete action
if (isset($_POST['mark_complete'])) {
  $lesson_id = $_POST['lesson_id'];

  // Check if there's a quiz associated with this lesson
  $quiz_check = $conn->prepare("SELECT id FROM quizzes WHERE lesson_id = ?");
  $quiz_check->bind_param("i", $lesson_id);
  $quiz_check->execute();
  $quiz_result = $quiz_check->get_result();
  $has_quiz = $quiz_result->num_rows > 0;

  if ($has_quiz) {
    // Check if the user has completed the quiz for this lesson
    $quiz_check = $conn->prepare("SELECT status FROM progress WHERE user_id = ? AND lesson_id = ? AND status = 'completed'");
    $quiz_check->bind_param("ii", $user_id, $lesson_id);
    $quiz_check->execute();
    $quiz_result = $quiz_check->get_result();

    if ($quiz_result->num_rows > 0) {
      // Quiz completed, now mark the lesson as completed
      $stmt = $conn->prepare("UPDATE progress SET status = 'completed' WHERE user_id = ? AND lesson_id = ?");
      $stmt->bind_param("ii", $user_id, $lesson_id);
      $stmt->execute();
      echo "<p style='color: green; text-align: center;'>Lesson marked as completed!</p>";
    } else {
      echo "<p style='color: red; text-align: center;'>You must complete the quiz before marking the lesson as completed.</p>";
    }
  } else {
    // If no quiz exists, mark the lesson as completed
    $stmt = $conn->prepare("UPDATE progress SET status = 'completed' WHERE user_id = ? AND lesson_id = ?");
    $stmt->bind_param("ii", $user_id, $lesson_id);
    $stmt->execute();
    echo "<p style='color: green; text-align: center;'>Lesson marked as completed!</p>";
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Lessons</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f9;
      padding: 30px;
      margin: 0;
    }

    .container {
      max-width: 800px;
      margin: auto;
      background: white;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
    }

    h2 {
      text-align: center;
      color: #333;
      margin-bottom: 25px;
    }

    .lesson-card {
      background: #fff;
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .lesson-card h3 {
      font-size: 20px;
      color: #333;
    }

    .lesson-card p {
      font-size: 16px;
      line-height: 1.5;
      color: #555;
    }

    .video-container {
      margin-top: 10px;
      display: flex;
      justify-content: center;
    }

    video, iframe {
      width: 100%;
      max-width: 600px;
      border-radius: 6px;
    }

    .status {
      margin-top: 15px;
      padding: 6px 10px;
      border-radius: 4px;
      font-weight: bold;
    }

    .completed {
      background-color: #d4edda;
      color: #155724;
    }

    .not_started {
      background-color: #f8d7da;
      color: #721c24;
    }

    .quiz-link {
      margin-top: 10px;
      text-align: center;
    }

    .quiz-link a {
      text-decoration: none;
      color: #007bff;
      font-size: 16px;
    }

    .quiz-link a:hover {
      text-decoration: underline;
    }

    .back-link {
      margin-top: 20px;
      text-align: center;
    }

    .back-link a {
      color: #007bff;
      text-decoration: none;
    }

    .back-link a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Lessons for Course ID <?= htmlspecialchars($course_id) ?></h2>

  <?php while ($lesson = $lessons->fetch_assoc()):
      $lesson_id = $lesson['id'];

      // Check if the user has marked the lesson as completed
      $progress_check = $conn->prepare("SELECT status FROM progress WHERE user_id = ? AND lesson_id = ?");
      $progress_check->bind_param("ii", $user_id, $lesson_id);
      $progress_check->execute();
      $progress_result = $progress_check->get_result();
      $progress_status = $progress_result->fetch_assoc()['status'] ?? 'not_started';
  ?>

  <div class="lesson-card">
    <h3><?= htmlspecialchars($lesson['title']) ?></h3>
    <p><?= nl2br(htmlspecialchars($lesson['content'])) ?></p>

    <?php if (!empty($lesson['video_url'])): ?>
      <div class="video-container">
        <?php
          // Check if the video URL is a YouTube URL
          if (strpos($lesson['video_url'], 'youtube.com') !== false || strpos($lesson['video_url'], 'youtu.be') !== false):
            // Extract the YouTube video ID from the URL
            preg_match("/(?:v=|\/)([a-zA-Z0-9_-]{11})/", $lesson['video_url'], $matches);
            $video_id = $matches[1];
        ?>
            <iframe width="100%" height="400" src="https://www.youtube.com/embed/<?= htmlspecialchars($video_id) ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <?php else: ?>
            <video controls>
              <source src="<?= htmlspecialchars($lesson['video_url']) ?>" type="video/mp4">
            </video>
        <?php endif; ?>
      </div>
    <?php endif; ?>

    <div class="status <?= $progress_status === 'completed' ? 'completed' : 'not_started' ?>">
      Status: <?= ucfirst($progress_status) ?>
    </div>

    <!-- Mark as completed button -->
    <?php if ($progress_status !== 'completed'): ?>
      <form method="POST">
        <input type="hidden" name="lesson_id" value="<?= $lesson_id ?>">
        <button type="submit" name="mark_complete">Mark as Complete</button>
      </form>
    <?php endif; ?>

    <!-- Quiz Link -->
    <?php
      $quiz_check = $conn->prepare("SELECT id FROM quizzes WHERE lesson_id = ?");
      $quiz_check->bind_param("i", $lesson_id);
      $quiz_check->execute();
      $quiz_result = $quiz_check->get_result();
      $has_quiz = $quiz_result->num_rows > 0;
      if ($has_quiz):
    ?>
      <div class="quiz-link">
      <a href="quiz.php?lesson_id=<?= $lesson_id ?>&course_id=<?= $_GET['course_id'] ?>">Take Quiz</a>

      </div>
    <?php endif; ?>
  </div>

  <?php endwhile; ?>

  <div class="back-link">
    <a href="courses.php">⬅ Back to Courses</a>
  </div>
</div>

</body>
</html>
